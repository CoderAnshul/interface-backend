import React, { forwardRef } from 'react';
import { ChevronDown } from 'lucide-react';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'> {
  label?: string;
  options: SelectOption[];
  error?: string;
  hint?: string;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ 
    label, 
    options, 
    error, 
    hint, 
    size = 'md', 
    fullWidth = true, 
    className = '', 
    ...props 
  }, ref) => {
    const sizeClasses = {
      sm: 'h-8 text-xs',
      md: 'h-10 text-sm',
      lg: 'h-12 text-base',
    };

    const selectClasses = `
      appearance-none block rounded-md border px-3 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-500
      ${sizeClasses[size]}
      ${error ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-blue-500'}
      ${fullWidth ? 'w-full' : ''}
      ${props.disabled ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : 'bg-white'}
      ${className}
    `;

    return (
      <div className={`${fullWidth ? 'w-full' : ''} space-y-1`}>
        {label && (
          <label htmlFor={props.id} className="block text-sm font-medium text-gray-700">
            {label}
          </label>
        )}
        <div className="relative">
          <select ref={ref} className={selectClasses} {...props}>
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
            <ChevronDown size={16} />
          </div>
        </div>
        {error && <p className="text-red-500 text-xs">{error}</p>}
        {hint && !error && <p className="text-gray-500 text-xs">{hint}</p>}
      </div>
    );
  }
);

Select.displayName = 'Select';

export default Select;