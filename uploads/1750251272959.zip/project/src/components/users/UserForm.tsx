import React, { useState } from 'react';
import { Mail, User, Lock, Upload, X } from 'lucide-react';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import { User as UserType } from '../../types';

interface UserFormProps {
  initialData?: Partial<UserType>;
  onSubmit: (data: Partial<UserType>) => void;
  onCancel: () => void;
}

const UserForm: React.FC<UserFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
}) => {
  const [formData, setFormData] = useState<Partial<UserType>>(
    initialData || {
      name: '',
      email: '',
      role: 'student',
    }
  );
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(initialData?.avatar || null);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    
    if (errors.password) {
      setErrors({
        ...errors,
        password: '',
      });
    }
    
    // Check if passwords match
    if (confirmPassword && e.target.value !== confirmPassword) {
      setErrors({
        ...errors,
        confirmPassword: 'Passwords do not match',
      });
    } else if (confirmPassword) {
      setErrors({
        ...errors,
        confirmPassword: '',
      });
    }
  };
  
  const handleConfirmPasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setConfirmPassword(e.target.value);
    
    if (password !== e.target.value) {
      setErrors({
        ...errors,
        confirmPassword: 'Passwords do not match',
      });
    } else {
      setErrors({
        ...errors,
        confirmPassword: '',
      });
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name?.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.role) {
      newErrors.role = 'Role is required';
    }
    
    // Check password only for new users or if password is provided
    if (!initialData || password) {
      if (!initialData && !password) {
        newErrors.password = 'Password is required for new users';
      } else if (password.length < 8) {
        newErrors.password = 'Password must be at least 8 characters';
      }
      
      if (password !== confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Include password in data only if it's provided
      const dataToSubmit = {
        ...formData,
        // In a real app, you'd hash the password on the server
        // and never include it in client-side state
      };
      
      onSubmit(dataToSubmit);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      // Create a preview URL for the selected image
      const previewUrl = URL.createObjectURL(file);
      setAvatarPreview(previewUrl);
      
      // In a real app, you'd upload the file to a server and get a URL back
      // For this example, we'll just store the preview URL
      setFormData({
        ...formData,
        avatar: previewUrl,
      });
    }
  };
  
  const removeAvatar = () => {
    setAvatarPreview(null);
    setFormData({
      ...formData,
      avatar: undefined,
    });
  };
  
  const roleOptions = [
    { value: 'student', label: 'Student' },
    { value: 'instructor', label: 'Instructor' },
    { value: 'admin', label: 'Admin' },
  ];

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        {/* User Information */}
        <Card title="User Information" description="Add basic user details">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-6">
            <div className="sm:col-span-6">
              <div className="flex justify-center">
                {avatarPreview ? (
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full overflow-hidden">
                      <img 
                        src={avatarPreview} 
                        alt="Avatar" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={removeAvatar}
                      className="absolute top-0 right-0 p-1 bg-white rounded-full shadow-md text-gray-700 hover:text-red-500"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center cursor-pointer">
                    <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300 transition-colors">
                      <Upload size={24} className="text-gray-500" />
                    </div>
                    <span className="mt-2 text-sm text-gray-500">Upload avatar</span>
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={handleAvatarChange}
                    />
                  </label>
                )}
              </div>
            </div>
            
            <div className="sm:col-span-6">
              <Input
                label="Full Name"
                id="name"
                name="name"
                value={formData.name || ''}
                onChange={handleChange}
                error={errors.name}
                placeholder="John Doe"
                leftIcon={<User size={16} />}
                required
              />
            </div>
            
            <div className="sm:col-span-4">
              <Input
                label="Email Address"
                id="email"
                name="email"
                type="email"
                value={formData.email || ''}
                onChange={handleChange}
                error={errors.email}
                placeholder="john@example.com"
                leftIcon={<Mail size={16} />}
                required
              />
            </div>
            
            <div className="sm:col-span-2">
              <Select
                label="Role"
                id="role"
                name="role"
                value={formData.role || 'student'}
                onChange={handleChange}
                error={errors.role}
                options={roleOptions}
                required
              />
            </div>
          </div>
        </Card>
        
        {/* Authentication */}
        <Card title="Authentication" description={initialData ? "Update user's password (optional)" : "Set up user's password"}>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <Input
                label="Password"
                id="password"
                name="password"
                type="password"
                value={password}
                onChange={handlePasswordChange}
                error={errors.password}
                placeholder={initialData ? "Leave blank to keep current password" : "Enter password"}
                leftIcon={<Lock size={16} />}
                required={!initialData}
              />
            </div>
            
            <div>
              <Input
                label="Confirm Password"
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={handleConfirmPasswordChange}
                error={errors.confirmPassword}
                placeholder="Confirm password"
                leftIcon={<Lock size={16} />}
                required={!initialData || !!password}
                disabled={!password}
              />
            </div>
          </div>
        </Card>
        
        {/* Form Actions */}
        <div className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            isLoading={isSubmitting}
          >
            {initialData ? 'Update User' : 'Create User'}
          </Button>
        </div>
      </div>
    </form>
  );
};

export default UserForm;