import React from 'react';
import { 
  Home, 
  BookOpen, 
  Users, 
  FileText, 
  BarChart2, 
  Settings,
  LogOut,
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

interface NavItem {
  title: string;
  icon: React.ReactNode;
  path: string;
  active?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const navItems: NavItem[] = [
    { title: 'Dashboard', icon: <Home size={20} />, path: '/', active: true },
    { title: 'Courses', icon: <BookOpen size={20} />, path: '/courses' },
    { title: 'Users', icon: <Users size={20} />, path: '/users' },
    { title: 'Lessons', icon: <FileText size={20} />, path: '/lessons' },
    { title: 'Reports', icon: <BarChart2 size={20} />, path: '/reports' },
    { title: 'Settings', icon: <Settings size={20} />, path: '/settings' },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:z-0
      `}>
        {/* Sidebar header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-md flex items-center justify-center">
              <BookOpen size={20} className="text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">LearnAdmin</h1>
          </div>
          <button 
            onClick={toggleSidebar} 
            className="lg:hidden text-gray-500 hover:text-gray-700"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-2 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.title}
              href={item.path}
              className={`
                flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
                ${item.active 
                  ? 'bg-blue-50 text-blue-700' 
                  : 'text-gray-700 hover:bg-gray-100'
                }
              `}
            >
              <span className="mr-3">{item.icon}</span>
              {item.title}
            </a>
          ))}
        </nav>

        {/* Sidebar footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center">
            <img 
              src="https://i.pravatar.cc/150?img=1" 
              alt="Admin User" 
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <p className="text-sm font-medium text-gray-900">Admin User</p>
              <p className="text-xs text-gray-500">admin@example.com</p>
            </div>
          </div>
          <button className="mt-4 flex items-center text-red-600 text-sm font-medium hover:text-red-700">
            <LogOut size={16} className="mr-2" />
            Sign out
          </button>
        </div>
      </div>

      {/* Mobile toggle button */}
      <button
        className="fixed bottom-4 right-4 p-3 bg-blue-600 rounded-full shadow-lg text-white lg:hidden z-50"
        onClick={toggleSidebar}
      >
        <Menu size={24} />
      </button>
    </>
  );
};

export default Sidebar;