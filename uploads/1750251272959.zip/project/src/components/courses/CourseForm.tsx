import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Textarea from '../ui/Textarea';
import Button from '../ui/Button';
import { Course } from '../../types';

interface CourseFormProps {
  initialData?: Partial<Course>;
  onSubmit: (data: Partial<Course>) => void;
  onCancel: () => void;
}

const CourseForm: React.FC<CourseFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
}) => {
  const [formData, setFormData] = useState<Partial<Course>>(
    initialData || {
      title: '',
      description: '',
      category: '',
      price: 0,
      duration: 0,
      status: 'draft',
    }
  );
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(initialData?.thumbnail || null);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    // Handle numeric inputs
    if (type === 'number') {
      setFormData({
        ...formData,
        [name]: parseFloat(value) || 0,
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!formData.category?.trim()) {
      newErrors.category = 'Category is required';
    }
    
    if (formData.price !== undefined && (formData.price < 0 || isNaN(formData.price))) {
      newErrors.price = 'Price must be a valid number';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      onSubmit(formData);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      // Create a preview URL for the selected image
      const previewUrl = URL.createObjectURL(file);
      setThumbnailPreview(previewUrl);
      
      // In a real app, you'd upload the file to a server and get a URL back
      // For this example, we'll just store the preview URL
      setFormData({
        ...formData,
        thumbnail: previewUrl,
      });
    }
  };
  
  const removeThumbnail = () => {
    setThumbnailPreview(null);
    setFormData({
      ...formData,
      thumbnail: undefined,
    });
  };
  
  const categoryOptions = [
    { value: '', label: 'Select a category' },
    { value: 'Web Development', label: 'Web Development' },
    { value: 'Mobile Development', label: 'Mobile Development' },
    { value: 'Design', label: 'Design' },
    { value: 'Business', label: 'Business' },
    { value: 'Marketing', label: 'Marketing' },
  ];
  
  const statusOptions = [
    { value: 'draft', label: 'Draft' },
    { value: 'published', label: 'Published' },
    { value: 'archived', label: 'Archived' },
  ];

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        {/* Basic Information */}
        <Card title="Basic Information" description="Add the core details about your course">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-6">
            <div className="sm:col-span-6">
              <Input
                label="Course Title"
                id="title"
                name="title"
                value={formData.title || ''}
                onChange={handleChange}
                error={errors.title}
                placeholder="e.g., Introduction to React Development"
                required
              />
            </div>
            
            <div className="sm:col-span-6">
              <Textarea
                label="Description"
                id="description"
                name="description"
                value={formData.description || ''}
                onChange={handleChange}
                error={errors.description}
                placeholder="Provide a detailed description of the course"
                required
                rows={4}
              />
            </div>
            
            <div className="sm:col-span-3">
              <Select
                label="Category"
                id="category"
                name="category"
                value={formData.category || ''}
                onChange={handleChange}
                error={errors.category}
                options={categoryOptions}
                required
              />
            </div>
            
            <div className="sm:col-span-3">
              <Select
                label="Status"
                id="status"
                name="status"
                value={formData.status || 'draft'}
                onChange={handleChange}
                options={statusOptions}
              />
            </div>
          </div>
        </Card>
        
        {/* Course Details */}
        <Card title="Course Details" description="Provide additional information about the course">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <Input
                label="Price ($)"
                id="price"
                name="price"
                type="number"
                min="0"
                step="0.01"
                value={formData.price?.toString() || '0'}
                onChange={handleChange}
                error={errors.price}
                hint="Leave 0 for free courses"
              />
            </div>
            
            <div className="sm:col-span-3">
              <Input
                label="Duration (hours)"
                id="duration"
                name="duration"
                type="number"
                min="0"
                step="0.5"
                value={formData.duration?.toString() || '0'}
                onChange={handleChange}
                error={errors.duration}
                hint="Estimated completion time"
              />
            </div>
            
            <div className="sm:col-span-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Course Thumbnail
              </label>
              
              {thumbnailPreview ? (
                <div className="relative w-full h-48 rounded-lg border-2 border-gray-300 overflow-hidden">
                  <img 
                    src={thumbnailPreview} 
                    alt="Course thumbnail" 
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={removeThumbnail}
                    className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md text-gray-700 hover:text-red-500"
                  >
                    <X size={18} />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload size={24} className="text-gray-400 mb-2" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">
                      SVG, PNG, JPG or GIF (Max. 2MB)
                    </p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleThumbnailChange}
                  />
                </label>
              )}
            </div>
          </div>
        </Card>
        
        {/* Form Actions */}
        <div className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            isLoading={isSubmitting}
          >
            {initialData ? 'Update Course' : 'Create Course'}
          </Button>
        </div>
      </div>
    </form>
  );
};

export default CourseForm;