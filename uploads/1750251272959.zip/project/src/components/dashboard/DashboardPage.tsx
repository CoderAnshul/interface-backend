import React from 'react';
import { Users, BookOpen, GraduationCap, DollarSign, BarChart2, Activity } from 'lucide-react';
import Layout from '../layout/Layout';
import StatCard from './StatCard';
import Card from '../ui/Card';
import { statistics, courses, users } from '../../data/mockData';

const DashboardPage: React.FC = () => {
  return (
    <Layout title="Dashboard" subtitle="Overview of your learning platform">
      {/* Stats grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 mb-8">
        <StatCard
          title="Total Users"
          value={statistics.totalUsers}
          icon={<Users size={24} />}
          change="+12% from last month"
          trend="up"
        />
        <StatCard
          title="Total Courses"
          value={statistics.totalCourses}
          icon={<BookOpen size={24} />}
          change="+5% from last month"
          trend="up"
        />
        <StatCard
          title="Enrollments"
          value={statistics.totalEnrollments}
          icon={<GraduationCap size={24} />}
          change="+18% from last month"
          trend="up"
        />
        <StatCard
          title="Revenue"
          value={`$${statistics.revenueThisMonth}`}
          icon={<DollarSign size={24} />}
          change="+8% from last month"
          trend="up"
        />
      </div>

      {/* Charts and tables section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent courses */}
        <Card title="Recent Courses" description="Latest courses added to the platform">
          <div className="space-y-4">
            {courses.slice(0, 3).map((course) => (
              <div key={course.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-12 h-12 rounded overflow-hidden">
                  <img 
                    src={course.thumbnail || 'https://via.placeholder.com/100'} 
                    alt={course.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{course.title}</p>
                  <p className="text-xs text-gray-500">
                    {course.category} • {course.status}
                  </p>
                </div>
                <div className="text-sm font-medium text-blue-600">
                  ${course.price}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <a href="/courses" className="text-sm font-medium text-blue-600 hover:text-blue-700">
              View all courses →
            </a>
          </div>
        </Card>

        {/* Recent users */}
        <Card title="Recent Users" description="Latest users who joined the platform">
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-10 h-10 rounded-full overflow-hidden">
                  <img 
                    src={user.avatar || 'https://via.placeholder.com/100'} 
                    alt={user.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{user.name}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {user.role}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <a href="/users" className="text-sm font-medium text-blue-600 hover:text-blue-700">
              View all users →
            </a>
          </div>
        </Card>

        {/* Platform activity */}
        <Card title="Platform Activity" description="Recent activities on your platform">
          <div className="flex flex-col space-y-3">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <Activity size={16} className="text-blue-600" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-900">
                    <span className="font-medium">Jane Student</span> completed the course{' '}
                    <span className="font-medium">Introduction to React</span>
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(Date.now() - 1000 * 60 * 60 * (index + 1)).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Performance stats */}
        <Card title="Performance Metrics" description="Key performance indicators">
          <div className="space-y-5">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">Active Users</span>
                <span className="text-sm font-medium text-gray-700">{statistics.activeUsers}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${statistics.activeUsers}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">Course Completion Rate</span>
                <span className="text-sm font-medium text-gray-700">{statistics.completionRate}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: `${statistics.completionRate}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">Engagement Rate</span>
                <span className="text-sm font-medium text-gray-700">76%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-amber-500 h-2 rounded-full" style={{ width: '76%' }}></div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </Layout>
  );
};

export default DashboardPage;