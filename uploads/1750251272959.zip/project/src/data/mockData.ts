// Mock data for development purposes
import { User, Course, Lesson, Enrollment } from '../types';

// Mock Users
export const users: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    avatar: 'https://i.pravatar.cc/150?img=1',
    createdAt: new Date('2023-01-01'),
  },
  {
    id: '2',
    name: 'John Instructor',
    email: 'instructor@example.com',
    role: 'instructor',
    avatar: 'https://i.pravatar.cc/150?img=2',
    createdAt: new Date('2023-01-15'),
  },
  {
    id: '3',
    name: 'Jane Student',
    email: 'student@example.com',
    role: 'student',
    avatar: 'https://i.pravatar.cc/150?img=3',
    createdAt: new Date('2023-02-01'),
  },
];

// Mock Courses
export const courses: Course[] = [
  {
    id: '1',
    title: 'Introduction to React',
    description: 'Learn the fundamentals of React development and build your first app.',
    instructorId: '2',
    thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    price: 49.99,
    duration: 12,
    category: 'Web Development',
    status: 'published',
    createdAt: new Date('2023-03-01'),
    updatedAt: new Date('2023-03-15'),
  },
  {
    id: '2',
    title: 'Advanced TypeScript',
    description: 'Master TypeScript for large-scale applications and type-safe programming.',
    instructorId: '2',
    thumbnail: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    price: 79.99,
    duration: 15,
    category: 'Programming',
    status: 'published',
    createdAt: new Date('2023-04-01'),
    updatedAt: new Date('2023-04-10'),
  },
  {
    id: '3',
    title: 'UI/UX Design Principles',
    description: 'Learn design thinking and create beautiful user experiences.',
    instructorId: '2',
    thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    price: 59.99,
    duration: 10,
    category: 'Design',
    status: 'draft',
    createdAt: new Date('2023-05-01'),
    updatedAt: new Date('2023-05-05'),
  },
];

// Mock Lessons
export const lessons: Lesson[] = [
  {
    id: '1',
    courseId: '1',
    title: 'Getting Started with React',
    description: 'Setting up your development environment and creating your first React app.',
    contentType: 'video',
    content: 'https://example.com/video1.mp4',
    duration: 45,
    order: 1,
    createdAt: new Date('2023-03-02'),
    updatedAt: new Date('2023-03-02'),
  },
  {
    id: '2',
    courseId: '1',
    title: 'React Components and Props',
    description: 'Understanding the component architecture and data flow with props.',
    contentType: 'video',
    content: 'https://example.com/video2.mp4',
    duration: 50,
    order: 2,
    createdAt: new Date('2023-03-05'),
    updatedAt: new Date('2023-03-05'),
  },
  {
    id: '3',
    courseId: '2',
    title: 'TypeScript Basics',
    description: 'Introduction to TypeScript syntax and basic types.',
    contentType: 'video',
    content: 'https://example.com/video3.mp4',
    duration: 60,
    order: 1,
    createdAt: new Date('2023-04-02'),
    updatedAt: new Date('2023-04-02'),
  },
];

// Mock Enrollments
export const enrollments: Enrollment[] = [
  {
    id: '1',
    userId: '3',
    courseId: '1',
    enrolledAt: new Date('2023-03-20'),
    status: 'active',
  },
  {
    id: '2',
    userId: '3',
    courseId: '2',
    enrolledAt: new Date('2023-04-15'),
    status: 'active',
  },
];

// Mock statistics for dashboard
export const statistics = {
  totalUsers: 150,
  totalCourses: 25,
  totalEnrollments: 543,
  revenueThisMonth: 12450,
  activeUsers: 87,
  completionRate: 68,
};