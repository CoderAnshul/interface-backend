import React, { useState } from 'react';
import DashboardPage from './components/dashboard/DashboardPage';
import CourseListPage from './components/courses/CourseListPage';
import CourseForm from './components/courses/CourseForm';
import UserListPage from './components/users/UserListPage';
import UserForm from './components/users/UserForm';
import { Course, User } from './types';

function App() {
  // For demo purposes, we'll use state to navigate between pages
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const [selectedCourse, setSelectedCourse] = useState<Partial<Course> | null>(null);
  const [selectedUser, setSelectedUser] = useState<Partial<User> | null>(null);
  
  // Mock functions for form submissions
  const handleCourseSubmit = (data: Partial<Course>) => {
    console.log('Course data submitted:', data);
    setCurrentPage('courses');
  };
  
  const handleUserSubmit = (data: Partial<User>) => {
    console.log('User data submitted:', data);
    setCurrentPage('users');
  };

  // Render the appropriate page based on state
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      
      case 'courses':
        return <CourseListPage />;
      
      case 'new-course':
        return (
          <CourseForm 
            onSubmit={handleCourseSubmit}
            onCancel={() => setCurrentPage('courses')}
          />
        );
      
      case 'edit-course':
        return (
          <CourseForm 
            initialData={selectedCourse || {}}
            onSubmit={handleCourseSubmit}
            onCancel={() => setCurrentPage('courses')}
          />
        );
      
      case 'users':
        return <UserListPage />;
      
      case 'new-user':
        return (
          <UserForm 
            onSubmit={handleUserSubmit}
            onCancel={() => setCurrentPage('users')}
          />
        );
      
      case 'edit-user':
        return (
          <UserForm 
            initialData={selectedUser || {}}
            onSubmit={handleUserSubmit}
            onCancel={() => setCurrentPage('users')}
          />
        );
      
      default:
        return <DashboardPage />;
    }
  };

  // Override links for demo purposes
  React.useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      if (anchor) {
        e.preventDefault();
        const href = anchor.getAttribute('href');
        
        if (href === '/') {
          setCurrentPage('dashboard');
        } else if (href === '/courses') {
          setCurrentPage('courses');
        } else if (href === '/users') {
          setCurrentPage('users');
        }
      }
      
      // Handle button clicks for demo
      if (target.closest('button')) {
        const buttonText = target.textContent?.trim().toLowerCase();
        
        if (buttonText === 'add course') {
          e.preventDefault();
          setCurrentPage('new-course');
        } else if (buttonText === 'add user') {
          e.preventDefault();
          setCurrentPage('new-user');
        }
      }
    };
    
    document.addEventListener('click', handleClick);
    
    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {renderPage()}
    </div>
  );
}

export default App;